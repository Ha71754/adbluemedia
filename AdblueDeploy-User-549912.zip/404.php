<?php
header('HTTP/1.1 400 Not Found', true, 400);
?>
<html>
<head></head>
<body>
<p>The page your were looking for could not be found.</p>
</body>
</html>